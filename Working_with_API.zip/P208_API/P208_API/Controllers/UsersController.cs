﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Web.Http;
using P208_API.Models;
using System.Threading.Tasks;

namespace P208_API.Controllers
{
    public class UsersController : ApiController
    {
        private readonly APIEntities _db;

        public UsersController()
        {
            _db = new APIEntities();
        }

        // GET: api/Users
        public IHttpActionResult Get(string token)
        {
            if (_db.DevUsers.FirstOrDefault(d => d.Token == token) == null)
                return Unauthorized();

            return Ok(_db.Users);

            //HttpResponseMessage response = Request.CreateResponse(HttpStatusCode.OK, users);
            //return response;
        }

        // GET: api/Users/5
        public IHttpActionResult  Get(int id)
        {
            User user = _db.Users.Find(id);

            if (user == null)
                return NotFound();

            return Ok(user);
        }

        // POST: api/Users
        public HttpResponseMessage Post([FromBody]User user)
        {
            if (_db.Users.FirstOrDefault(u => u.Email == user.Email) != null)
                return Request.CreateResponse(HttpStatusCode.Forbidden);

            _db.Users.Add(user);
            _db.SaveChanges();

            return Request.CreateResponse(HttpStatusCode.Created, new { user.Firstname, user.Lastname });
        }

        // PUT: api/Users/5
        public async Task<IHttpActionResult> Put(int id, User user)
        {
            User updated = _db.Users.Find(id);

            if (updated == null)
                return NotFound();

            updated.Firstname = user.Firstname;
            updated.Lastname = user.Lastname;
            updated.Email = user.Email;

            await _db.SaveChangesAsync();

            return Ok();
        }

        // DELETE: api/Users/5
        public async Task<IHttpActionResult> Delete(int id)
        {
            User user = _db.Users.Find(id);

            if (user == null)
                return NotFound();

            _db.Users.Remove(user);
            await _db.SaveChangesAsync();

            return  Ok(id);
        }
    }
}
