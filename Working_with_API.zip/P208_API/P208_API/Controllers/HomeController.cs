﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using RestSharp;
using P208_API.Models;

namespace P208_API.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            var client = new RestClient("https://reqres.in/api/users?page=2");
            var request = new RestRequest(Method.GET);
            IRestResponse<UserData> response2 = client.Execute<UserData>(request);

            return View(response2.Data);
        }
    }
}
